import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-chat-message',
  templateUrl: './chat-message.component.html',
  styleUrls: ['./chat-message.component.css']
})
export class ChatMessageComponent implements OnInit {
  isVisible;
  chatMsgForm: FormGroup;
  chatMsgList:any[];
  visibleSidebar4:boolean
  @Output() closeCancel: EventEmitter<any> = new EventEmitter();
  @Input() 
	isShow : boolean; 
  constructor( private readonly formBuilder: FormBuilder) { 
   
    this.chatMsgList=[]
  }

  ngOnInit() {
    this.chatMsgForm = this.formBuilder.group({
      chatMsg: ['']
    });
  }

  saveChatMsg(){
    this.chatMsgList.push(this.chatMsgForm.controls.chatMsg.value)
    this.chatMsgForm.controls.chatMsg.reset();
  }
  onClose(){
    this.closeCancel.emit(false);
  }

}
