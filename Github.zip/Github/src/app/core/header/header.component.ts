import { Component, OnInit, HostListener, ElementRef } from '@angular/core';
import { HeaderService } from './service/header.service';
import { FormControl } from '@angular/forms';
import { debounceTime } from 'rxjs/operators';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
  host: {
    '(document:click)': 'onClick($event)',
  },
  
})
export class HeaderComponent implements OnInit {

results: any[] = [];
queryField: FormControl = new FormControl();
private active:boolean = false;
  brandsd = [
    {
      title: 'Raw Data',
      icon: 'fa fa-database', data: ['kamal claims', 'kamal claims']
    }, {
      title: 'Insights', data: ['Midhu claims', 'kamal claims']
    }, {
      title: 'Dashboard', data: ['kamal claims', 'kamal claims']
    }, { title: 'Recommended Authors', data: ['John smith', 'David Jones', 'Gwen stacy'] }
  ];

  filteredBrands: any[];
  filtered: any[];
  brand: string;

  constructor(private headerService: HeaderService,private elementRef: ElementRef) { 
    this.filtered = [];
  }
  onClick(event) {
    if (!this.elementRef.nativeElement.contains(event.target)){
      this.active=false;
    } // or some similar check
      
   }
  ngOnInit() {
    this.queryField.valueChanges.pipe(debounceTime(200))
    .subscribe( result => this.filterBrands(result));
  }
  getRequest(event) {
    let d = event;
  }
  navigateTo(){
    
  }
  onClear(event) {
    let d = event;
  }
  // @HostListener('document:click', ['$event'])
  // public onClickOutside(event): void {
  //   const targetElement = event.target as HTMLElement;
 
  //     // Check if the click was outside the element
  //     if (targetElement && !this.elementRef.nativeElement.contains(targetElement)) {
  //       if(event && event['value'] === true) {
  //         this.active = false;
  //       }
  //     }
  // }
 
  filterBrands(event) {
    this.active=true;
    this.filteredBrands = [];
    this.filtered = [];
    if(event!=''){
      for (let i = 0; i < this.brandsd.length; i++) {
        this.filteredBrands = [];
        if(this.brandsd[i]['title'] !== 'Recommended Authors'){
          this.filteredBrands = this.brandsd[i]['data'].filter(
            (val)=> val.toLowerCase().includes(event.toLowerCase()))
        }
        if (this.filteredBrands.length > 0) {
          this.filtered.push({
            title: this.brandsd[i]['title'],
            data: this.filteredBrands
          })
        }
        if (this.brandsd[i]['title'] == 'Recommended Authors') {
          this.filtered.push(this.brandsd[i]);
        }
      }
      if (this.filtered.length == 0){
        this.filtered.push({
          title: 'empty'
        })
      }
    }
    else{
      this.active=false;
    }
    
  }
}
