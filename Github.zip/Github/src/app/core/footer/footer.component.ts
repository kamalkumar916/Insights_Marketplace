import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  isVisible: boolean = false;
  @Output() open: EventEmitter<any> = new EventEmitter();


  constructor() { }
  ngOnInit() {
  }
  toggle() {
   this.isVisible=true;
  }
  close(event){
    this.isVisible=false;
  }
}
