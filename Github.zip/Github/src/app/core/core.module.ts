import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppRoutingModule } from '../app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CardModule } from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { HttpClientModule } from '@angular/common/http';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { BrowserModule } from '@angular/platform-browser';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ChatMessageComponent } from '../shared/chat-message/chat-message.component';
import {DialogModule} from 'primeng/dialog';

import {SidebarModule} from 'primeng/sidebar';
import {SplitButtonModule} from 'primeng/splitbutton';


@NgModule({
  declarations: [
    HeaderComponent,
   FooterComponent,
    ChatMessageComponent
  ],
  imports: [
    CommonModule,
    AppRoutingModule,
    FormsModule,
    CardModule,
    ButtonModule,
    InputTextModule,
    HttpClientModule,
    OverlayPanelModule,
    ReactiveFormsModule,
    DialogModule,
    SidebarModule,
    SplitButtonModule
  ],
  exports:[HeaderComponent,
    FooterComponent,
    ChatMessageComponent]
})
export class CoreModule { }
