import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InsightsHomeComponent } from './features/insights-home/insights-home.component';
import { RequestInsightsComponent } from './features/request-insights/request-insights.component';
import { ViewReportsByCityComponent } from './features/view-reports-by-city/view-reports-by-city.component';


const routes: Routes = [
  {
    path: "",
   loadChildren: './features/insights-home/insights-home.module#InsightsHomeModule',
  //  component:InsightsHomeComponent
  

  },
  {
    path: 'home',
    loadChildren: './features/insights-home/insights-home.module#InsightsHomeModule',
   // component:InsightsHomeComponent
   
  },
  {
    path: 'request',
    loadChildren: './features/request-insights/request-insights.module#RequestInsightsModule',
    // component:RequestInsightsComponent
  

  },
  {
    path: 'view-reports',
    loadChildren:'./features/view-reports-by-city/view-reports-by-city.module#ViewReportsByCityModule',
    // component: ViewReportsByCityComponent
  
  }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
