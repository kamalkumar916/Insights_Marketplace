export function reducer(state, action){
switch(action.type){
    case 'TOGGLE_RADIO':
        console.log('exixting state:'+ JSON.stringify(state));
        console.log('payload:'+action.payLoad);
        return {
            ...state,
            showProductCode:action.payLoad
        };
        default: return state;
 
}
}