import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestInsightsComponent } from './request-insights.component';

describe('RequestInsightsComponent', () => {
  let component: RequestInsightsComponent;
  let fixture: ComponentFixture<RequestInsightsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RequestInsightsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestInsightsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
