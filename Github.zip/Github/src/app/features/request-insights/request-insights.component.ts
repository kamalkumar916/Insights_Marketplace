import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';

@Component({
  selector: 'app-request-insights',
  templateUrl: './request-insights.component.html',
  styleUrls: ['./request-insights.component.css']
})
export class RequestInsightsComponent implements OnInit {

  constructor(private store: Store<any>) { }
  displayCode:boolean;
  ngOnInit() {
    this.store.pipe(select('request')).subscribe(product=>{
      if(product){
        this.displayCode=product.showProductCode;
      }
    })
  }
  checkChanged(value: boolean): void {
    this.store.dispatch({
      type: 'TOGGLE_RADIO',
      payLoad: value
    })
  }
}
