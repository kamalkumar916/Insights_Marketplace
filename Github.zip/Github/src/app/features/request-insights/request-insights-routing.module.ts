import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RequestInsightsComponent } from './request-insights.component';
import { StoreModule } from '@ngrx/store';
import { reducer } from './state/request.reducer';


const routes: Routes = [
  {path:'', component:RequestInsightsComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes),
    StoreModule.forFeature('request',reducer)],
  exports: [RouterModule]
})
export class RequestInsightsRoutingModule { }
