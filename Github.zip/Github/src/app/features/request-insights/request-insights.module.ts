import { NgModule } from '@angular/core';
import {CardModule} from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {PanelModule} from 'primeng/panel';
import {CarouselModule} from 'primeng/carousel';
import { RequestInsightsComponent } from './request-insights.component';
import {InputTextModule} from 'primeng/inputtext';
import {CalendarModule} from 'primeng/calendar';
import {RadioButtonModule} from 'primeng/radiobutton';
import {InputTextareaModule} from 'primeng/inputtextarea';
import { RequestInsightsRoutingModule } from './request-insights-routing.module';
import {StoreModule} from '@ngrx/store';
import { reducer } from './state/request.reducer';

@NgModule({
  declarations: [RequestInsightsComponent],
  imports: [
    CardModule,
    ButtonModule,
    PanelModule,
    CarouselModule,
    InputTextModule,
    CalendarModule,
    RadioButtonModule,
    InputTextareaModule,
    RequestInsightsRoutingModule,

    
  ],
  exports: [RequestInsightsComponent]
})
export class RequestInsightsModule { }
