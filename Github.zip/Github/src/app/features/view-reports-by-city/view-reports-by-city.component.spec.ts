import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewReportsByCityComponent } from './view-reports-by-city.component';

describe('ViewReportsByCityComponent', () => {
  let component: ViewReportsByCityComponent;
  let fixture: ComponentFixture<ViewReportsByCityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewReportsByCityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewReportsByCityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
