import { Component, OnInit } from '@angular/core';
import {MenuItem} from 'primeng/api';
@Component({
  selector: 'app-view-reports-by-city',
  templateUrl: './view-reports-by-city.component.html',
  styleUrls: ['./view-reports-by-city.component.css']
})
export class ViewReportsByCityComponent implements OnInit {
years:any[];
  items: MenuItem[];
  cities:any[];
  statsActive:boolean;
  graphActive:boolean;
  constructor() { 
    this.statsActive=true;
    this.graphActive=false
  }
  ngOnInit() {
      this.items = [
          {label: 'Stats'},
          {label: 'Graph'}
        
      ];
      this.cities = [
        {name: 'New York', code: 'NY'},
        {name: 'Rome', code: 'RM'},
        {name: 'London', code: 'LDN'},
        {name: 'Istanbul', code: 'IST'},
        {name: 'Paris', code: 'PRS'}
    ];
    this.years = [
      {name: '2019', code: 'NY'},
      {name: '2018', code: 'RM'},
      {name: '2017', code: 'LDN'},
      {name: '2016', code: 'IST'},
      {name: '2015', code: 'PRS'}
  ];
  }
  
  activateMenu(tab){
    if (tab.activeItem.label === 'Stats') {
      this.statsActive = true;
      this.graphActive = false;
    }
    else if (tab.activeItem.label === 'Graph') {
      this.graphActive = true;
      this.statsActive = false;
    }
  }
}
