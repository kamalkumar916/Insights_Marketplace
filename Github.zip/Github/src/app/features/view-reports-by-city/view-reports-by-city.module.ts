import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { ViewReportsByCityComponent } from './view-reports-by-city.component';
import {TabMenuModule} from 'primeng/tabmenu';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import {MenuModule} from 'primeng/menu';
import {DropdownModule} from 'primeng/dropdown';
import {ButtonModule} from 'primeng/button';
import { ViewReportsByCityRoutingModule } from './view-reports-by-city-routing.module';
import { CommonModule } from '@angular/common';

@NgModule({
  declarations: [ViewReportsByCityComponent],
  imports: [
    TabMenuModule,
    FormsModule,
    ReactiveFormsModule,
    MenuModule,
    DropdownModule,
    ButtonModule,
    CommonModule, 
    ViewReportsByCityRoutingModule
  ],
  exports: [ViewReportsByCityComponent]
})
export class ViewReportsByCityModule { }
