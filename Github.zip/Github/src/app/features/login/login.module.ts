import { NgModule } from '@angular/core';
import {CardModule} from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {PanelModule} from 'primeng/panel';
import {CarouselModule} from 'primeng/carousel';
import {InputTextModule} from 'primeng/inputtext';
import {CalendarModule} from 'primeng/calendar';
import {RadioButtonModule} from 'primeng/radiobutton';
import {InputTextareaModule} from 'primeng/inputtextarea';
import { LoginComponent } from './login.component';


@NgModule({
  declarations: [LoginComponent],
  imports: [
    CardModule,
    ButtonModule,
    PanelModule,
    CarouselModule,
    InputTextModule,
    CalendarModule,
    RadioButtonModule,
    InputTextareaModule,
    
  ],
  exports: [LoginComponent]
})
export class LoginModule { }