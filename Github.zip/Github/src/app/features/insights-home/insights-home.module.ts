import { NgModule } from '@angular/core';
import { InsightsHomeComponent } from './insights-home.component';
import {CardModule} from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {PanelModule} from 'primeng/panel';
import {CarouselModule} from 'primeng/carousel';

import { InsightsSliderComponent } from './insights_slider/insights-slider/insights-slider.component';
import { InsightsHomeRoutingModule } from './insights-home-routing.module';


@NgModule({
  declarations: [InsightsHomeComponent, InsightsSliderComponent],
  imports: [
    CardModule,
    ButtonModule,
    PanelModule,
    CarouselModule,
    InsightsHomeRoutingModule
  ],
  exports: [InsightsHomeComponent]
})
export class InsightsHomeModule { }
