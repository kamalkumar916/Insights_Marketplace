import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-insights-slider',
  templateUrl: './insights-slider.component.html',
  styleUrls: ['./insights-slider.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class InsightsSliderComponent implements OnInit {
  responsiveOptions;
  cars: any[];
  constructor() { 
    this.responsiveOptions = [
      {
          breakpoint: '1024px',
          numVisible: 3,
          numScroll: 3
      },
      {
          breakpoint: '768px',
          numVisible: 2,
          numScroll: 2
      },
      {
          breakpoint: '560px',
          numVisible: 1,
          numScroll: 1
      }
  ];
  }

  ngOnInit() {
    this.cars=[{
      brand:'img1',
      year:2018,
      color:'red'
    },
    {
      brand:'img1',
      year:2018,
      color:'red'
    },
    {
      brand:'img1',
      year:2018,
      color:'red'
    },
    {
      brand:'img1',
      year:2018,
      color:'red'
    },
    {
      brand:'img1',
      year:2018,
      color:'red'
    },
    {
      brand:'img1',
      year:2018,
      color:'red'
    },
    {
      brand:'img1',
      year:2018,
      color:'red'
    },
    {
      brand:'img1',
      year:2018,
      color:'red'
    },
    {
      brand:'img1',
      year:2018,
      color:'red'
    }]
  }

}
