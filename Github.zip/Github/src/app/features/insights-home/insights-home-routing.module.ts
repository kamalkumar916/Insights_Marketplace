import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InsightsHomeComponent } from './insights-home.component';


const routes: Routes = [
  {path:'', component:InsightsHomeComponent},
  {path:'home', component:InsightsHomeComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InsightsHomeRoutingModule { }
