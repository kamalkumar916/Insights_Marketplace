import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-insights-home',
  templateUrl: './insights-home.component.html',
  styleUrls: ['./insights-home.component.css']

})
export class InsightsHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
 
}
